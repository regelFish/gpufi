#!/bin/bash
eval ${PRELOAD_FLAG} ${BIN_DIR}/simple_add > stdout.txt 2> stderr.txt
